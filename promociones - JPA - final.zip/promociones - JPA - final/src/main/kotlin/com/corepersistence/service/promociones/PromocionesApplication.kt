package com.corepersistence.service.promociones

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class PromocionesApplication

fun main(args: Array<String>) {
    runApplication<PromocionesApplication>(*args)
}
