package com.corepersistence.service.promociones

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class PromocionesApplicationTests {

    @Test
    fun contextLoads() {
    }

}
